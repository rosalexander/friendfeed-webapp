def Articles():
	Articles = [
		{
			'id': 1,
			'title':'Article One',
			'body' : 'Lorem ipsum dolor',
			'author' : 'Alex Ros',
			'create_date' : '04-25-2017'
		},
		{
			'id': 2,
			'title':'Article Two',
			'body' : 'Lorem ipsum dolor',
			'author' : 'Alex Ros',
			'create_date' : '04-26-2017'
		},
		{
			'id': 3,
			'title':'Article Three',
			'body' : 'Lorem ipsum dolor',
			'author' : 'Alex Ros',
			'create_date' : '04-27-2017'
		}

	]

	return Articles