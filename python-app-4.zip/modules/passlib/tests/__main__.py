import os
from nose import run
run(
    defaultTest=os.path.dirname(__file__),
)

